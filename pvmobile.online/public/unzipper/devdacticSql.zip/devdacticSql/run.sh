npm install && ionic lab
